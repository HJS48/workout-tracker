---
name: run-session
description: Guide a pre-run readiness check and intensity recommendation. Use when user says they're going for a run, heading out, or it's a run day.
---

# Run Session

Pre-run readiness assessment and intensity recommendation. Front-loaded then hands-off — user runs, Garmin syncs automatically, post-run review is optional.

## Pre-Run Flow

### 1. Sync first, then load data

Call `sync_garmin_data` FIRST and wait for it to complete. Stale morning data (e.g. body battery from 7am shown at 6pm) is useless — the sync ensures current values.

THEN call `get_readiness` and `get_active_mesocycle` in parallel.

### 2. Detect today's planned run from mesocycle

The mesocycle `notes` field contains the running schedule. It specifies which day-of-week maps to which run type, organized by week number.

Calculate the current week:
```
week = ceil((today - mesocycle.start_date + 1) / 7)
```

Look up today's day-of-week in the schedule to find the planned run type and details. If today isn't a scheduled run day, mention that but proceed if the user wants to run anyway.

### 3. Display readiness + planned session

Show objective metrics on one line:

```
Garmin: Sleep 7h25m | BB 59 (high 83, low 25) | Stress avg 10 | RHR 47
```

Note: Instinct Solar (original) provides body battery, stress, sleep stages, and RHR. HRV, sleep score, training readiness, and VO2 Max are not available on this device.

Then show the planned session structure:

**Intervals:**
```
Planned: Intervals — [details from schedule]
10 min warm-up → [reps] x [distance] w/ 90s jog recovery → 5 min cool-down
```

**Tempo:**
```
Planned: Tempo — [details from schedule]
10 min warm-up → [duration/distance] continuous → 5 min cool-down
```

**Easy / Long:**
```
Planned: Easy run — [distance/duration from schedule]
```
No structured warm-up for easy/long runs.

### 4. Ask subjective readiness

Prompt with leg-specific muscle groups:

```
Sleep / Energy / Quads / Calves / Hamstrings / Glutes / Hip flexors soreness:
```

Scales: Sleep 1-5, Energy 1-5, Soreness 0-5 per muscle group (0 = none).

Accept numeric (e.g. `4 3 0 0 1 0 0`) or verbal responses. Parse what you can. Don't force a re-answer — use reasonable defaults and move on.

### 5. Intensity recommendation

Combine objective and subjective data to recommend intensity:

| Condition | Recommendation |
|-----------|---------------|
| BB >50, energy 4-5, soreness mostly 0-1 | Proceed as planned |
| BB 30-50 or energy 2-3 | Consider swapping hard session for easy |
| BB <30 or energy 1 | Suggest easy run or rest day |
| Any muscle soreness 4-5 | Flag it — suggest easy or rest |
| Stress avg >50 | Mention it as a factor |

State the recommendation relative to what was planned. Don't insist — the user decides.

### 6. Log readiness

Call `log_run_readiness` with:
- `date` (today)
- `sleep_quality`, `energy_level`
- `muscle_soreness` as structured JSONB: `{"quads": 0, "calves": 1, "hamstrings": 0, "glutes": 0, "hip_flexors": 0}`
- `notes` if anything noteworthy

Confirm briefly: `Logged. Have a good run.`

That's it for pre-run. The user goes and runs. Garmin data syncs automatically and merges into the stub.

## Post-Run Flow

Triggers when the user comes back and says "how was the run", "back from my run", "just finished", or similar. Also triggers if the user sends a message after a run has synced.

### 1. Get the run data

Call `get_run_sessions` with today's date. The stub should now have Garmin data merged in.

### 2. Display summary

```
5.2km | 27:14 | 5:14/km avg
HR: avg 152, max 171 | Cadence: 168 spm
Fastest km: 4:48
```

Show what's available. Don't pad with zeros or "N/A" for missing fields.

### 3. Classify and update

If `run_type` is null (Garmin doesn't classify), ask:

```
Run type? (easy / tempo / interval / long / fartlek)
```

Once answered, call `update_run_session` with:
- `run_session_id` — from the session retrieved in step 1
- `run_type` — the classification
- `notes` — if the user volunteers any observations
- `perceived_effort` — if the user mentions effort level (1-10)

Combine into a single `update_run_session` call. If the user offers notes or effort later, make another call.

### 4. Context from readiness

If readiness was logged pre-run, connect the dots briefly:
- "Energy was 2 pre-run and pace was 15s/km slower than your last easy run — tracks."
- "BB was 35 but you ran faster than usual — nice."

Only mention when there's something worth noting. Don't force a correlation every time.

## Response style

- Keep it brief. Pre-run is 2-3 messages total.
- Post-run summary in one message unless the user wants to discuss.
- No "Great run!" unless it genuinely was (PR, faster than expected given low readiness).

## Data stored per run session

After a complete flow, the database will have:
- Run session row: date, subjective readiness (sleep_quality, energy_level, muscle_soreness), notes
- Garmin data merged in: distance, duration, pace, HR, cadence, laps, HR zones, splits
- Run type classification + perceived effort
- All queryable for correlation analysis
